package server2017tpOrdenar.ordenar;

public abstract class AlgoritmoOrdenar {

	public abstract void ordenar(int[] arreglo);
}
